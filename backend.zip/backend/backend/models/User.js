
const sequelize = require('../database-connection/sequelize') ;
const Sequelize = require("sequelize");
// Define a User model
const User = sequelize.define('User', {
    username: {
        type: Sequelize.STRING,
        primaryKey: true
    },
    password: Sequelize.STRING,
    
    
    }, {

    timestamps: false, }
    
    );

User.sync()
    .then(() => {
        console.log('User table Synced');
    })
    .catch(error => {
        console.log('Error creating User table:', error);
    });


module.exports = User;