const sequelize = require('../database-connection/sequelize');
const Sequelize = require('sequelize');

// Define a Student model
const Student = sequelize.define(
  'Student',
  {
    rollNumber: {
      type: Sequelize.STRING,
      primaryKey: true,
    },
    name: Sequelize.STRING,
    dob: Sequelize.DATE,
    score: Sequelize.INTEGER,
  },
  {
    timestamps: false,
  }
);

Student.sync()
    .then(() => {
        console.log('Student table Synced');
    })
    .catch(error => {
        console.log('Error creating Student table:', error);
    });

module.exports = Student;
