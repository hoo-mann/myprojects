const express = require('express');
const router = express.Router();
const userDao = require('../userDAO/userDao');

router.get("/users",(req,res) => {
    userDao.getUsers((error, users) => {
        if (error) {
        
          res.status(500).send("Internal Server Error");
        } else {
    
          res.json(users);
        }
      });
    console.log('users') ;
});


router.get("/users/:username", (req, res) => {
    const username = req.params.username;
  
    userDao.getUserByUsername(username, (error, user) => {
      if (error) {
        res.status(500).send("Internal Server Error");
      } else if (!user) {
        res.status(404).send("User not found");
      } else {
        res.json(user);
      }
    });
  });



router.post('/users', (req, res) => {
    const { username, password } = req.body;
  
   
    if (!username || !password) {
      return res.status(400).send('Missing required fields');
    }
  
    
    userDao.getUserByUsername(username, (error, existingUser) => {
      if (error) {
        return res.status(500).send('Internal Server Error');
      }
  
      if (existingUser) {
        return res.status(409).send('Username already exists');
      }
  
      
      const newUser = {
        username: username,
        password: password,
       
      };
  
      userDao.addUser(newUser, (error, user) => {
        if (error) {
          console.error('Error adding user:', error);
          return res.status(500).send('Internal Server Error');
        }
  
        console.log('Added user:', user);
        res.json(user);
      });
    });
  });
  

module.exports = router;