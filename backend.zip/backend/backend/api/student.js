const express = require('express');
const router = express.Router();
const studentDao = require('../studentDAO/studentDao');



router.get('/students', (req, res) => {
    studentDao.getAllStudents((error, students) => {
        if (error) {
            res.status(500).send('Internal Server Error');
        } else {
            res.json(students);
        }
    });
});

router.get('/students/:rollNumber', (req, res) => {
    const rollNumber = req.params.rollNumber;

    studentDao.getStudentByRollNumber(rollNumber, (error, student) => {
        if (error) {
            res.status(500).send('Internal Server Error');
        } else if (!student) {
            res.status(404).send('Student not found');
        } else {
            res.json(student);
        }
    });
});

router.post('/students', (req, res) => {
    const { rollNumber, name, dob, score } = req.body;

    if (!rollNumber || !name || !dob || !score) {
        return res.status(400).send('Missing required fields');
    }

    studentDao.getStudentByRollNumber(rollNumber, (error, existingStudent) => {
        if (error) {
            return res.status(500).send('Internal Server Error');
        }

        if (existingStudent) {
            return res.status(409).send('Student with the same roll number already exists');
        }

        const newStudent = {
            rollNumber: rollNumber,
            name: name,
            dob: dob,
            score: score,
        };

        studentDao.addStudent(newStudent, (error, student) => {
            if (error) {
                console.error('Error adding student:', error);
                return res.status(500).send('Internal Server Error');
            }

            console.log('Added student:', student);
            res.json(student);
        });
    });
});


router.put('/students/:rollNumber', (req, res) => {
    const rollNumber = req.params.rollNumber;
    const { name, dob, score } = req.body;

    if (!name || !dob || !score) {
        return res.status(400).send('Missing required fields');
    }

    studentDao.getStudentByRollNumber(rollNumber, (error, existingStudent) => {
        if (error) {
            return res.status(500).send('Internal Server Error');
        }

        if (!existingStudent) {
            return res.status(404).send('Student not found');
        }

        const updatedStudent = {
            rollNumber: rollNumber,
            name: name,
            dob: dob,
            score: score,
        };

        studentDao.updateStudent(rollNumber, updatedStudent, (error, student) => {
            if (error) {
                console.error('Error updating student:', error);
                return res.status(500).send('Internal Server Error');
            }

            console.log('Updated student:', student);
            res.json(student);
        });
    });
});

router.delete('/students/:rollNumber', (req, res) => {
    const rollNumber = req.params.rollNumber;

    studentDao.getStudentByRollNumber(rollNumber, (error, existingStudent) => {
        if (error) {
            return res.status(500).send('Internal Server Error');
        }

        if (!existingStudent) {
            return res.status(404).send('Student not found');
        }

        studentDao.deleteStudent(rollNumber, (error) => {
            if (error) {
                console.error('Error deleting student:', error);
                return res.status(500).send('Internal Server Error');
            }

            console.log('Deleted student with roll number:', rollNumber);
            res.sendStatus(204);
        });
    });
});


module.exports = router;