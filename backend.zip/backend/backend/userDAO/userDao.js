
const User = require('../models/User') ;


function getUsers(callback) {
  
    User.findAll()
    .then(users => {
    console.log('All users:', users);
    })
    .catch(error => {
    console.log('Error retrieving users:', error);
    });

}

function getUserByUsername(username, callback) {
  
  User.findOne({ where: { username } })
    .then(user => {
      if (!user) {
        callback(null, null); 
      } else {
        console.log('User:', user);
        callback(null, user); 
      }
    })
    .catch(error => {
      console.log('Error retrieving user:', error);
      callback(error, null); 
    });
}

function addUser(newUser, callback) {
  
  User.create(newUser)
    .then(user => {
      console.log('Added user:', user);
      callback(null, user);
    })
    .catch(error => {
      console.log('Error adding user:', error);
      callback(error, null); 
    });
}

module.exports = {
  getUsers,
  getUserByUsername,
  addUser ,
};