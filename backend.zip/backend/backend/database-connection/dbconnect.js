
const mysql = require("mysql2") ;


const db = mysql.createConnection({

    host:'database-2.cbgaqmhgmhsk.eu-north-1.rds.amazonaws.com' ,
    user:'admin' ,
    password :'12345678' ,
    database : 'School' ,
    port :3306 ,

    // host:'127.0.0.1' ,
    // user:'root' ,
    // password :'root' ,
    // database : 'School2' ,
    // port :3306 ,


}) ;

db.connect(err=> {
    if(err) {
        console.log(err ,"database error") ;
    }
 else{
    console.log("database connected") ; }
})



module.exports = db ;


