
const mysql = require("mysql2") ;


const db = mysql.createConnection({

    host:'database-1.cfv4eqrdw98w.eu-north-1.rds.amazonaws.com' ,
    user:'admin' ,
    password :'12345678' ,
    database : 'bookstore' ,
    port :3306 ,


}) ;

db.connect(err=> {
    if(err) {
        console.log(err ,"database error") ;
    }
 else{
    console.log("database connected") ; }
})



module.exports = db ;


