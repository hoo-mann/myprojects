const db = require('./database-connection/dbconnect')
const express = require('express') ;
const bodyparser = require('body-parser') ;
const cors = require('cors') ;


const app = express() ;

app.use(cors()) ;
app.use(bodyparser.json()) ;

app.use("" , require('./api/user'));
app.use("", require('./api/student'))

app.listen(80 , () => {

    console.log("server running") ;
})